### R code from vignette source 'jetset.Rnw'

###################################################
### code chunk number 1: jetset.Rnw:30-31
###################################################
  library(jetset)


###################################################
### code chunk number 2: jetset.Rnw:40-41
###################################################
  ls("package:jetset")


###################################################
### code chunk number 3: jetset.Rnw:62-63
###################################################
  head(scores.hgu95av2)


###################################################
### code chunk number 4: jetset.Rnw:100-104
###################################################
  jmap('hgu95av2', eg = "2099")
  jmap('hgu133a', eg = "2099")
  jmap('hgu133plus2', eg = "2099")
  jmap('u133x3p', eg = "2099")


###################################################
### code chunk number 5: jetset.Rnw:114-116
###################################################
  jmap('hgu95av2', ensembl = "ENSG00000091831")
  jmap('hgu133a', ensembl = "ENSG00000091831")


###################################################
### code chunk number 6: jetset.Rnw:124-125
###################################################
  jmap('hgu133a', symbol = c("ESR1", "ERBB2", "AURKA"))


###################################################
### code chunk number 7: jetset.Rnw:135-136
###################################################
  jmap('u133x3p', alias = c("P53", "HER-2", "K-RAS"))


###################################################
### code chunk number 8: jetset.Rnw:145-146
###################################################
  jscores('hgu95av2', symbol = 'STAT1')


###################################################
### code chunk number 9: jetset.Rnw:153-154
###################################################
  jmap('hgu95av2', symbol = 'STAT1')


###################################################
### code chunk number 10: jetset.Rnw:159-161
###################################################
  allscores <- jscores('hgu95av2')
  str(allscores)


###################################################
### code chunk number 11: jetset.Rnw:170-174
###################################################
table(!is.na(scores.hgu95av2$EntrezID))
table(!is.na(scores.hgu133a$EntrezID))
table(!is.na(scores.hgu133plus2$EntrezID))
table(!is.na(scores.u133x3p$EntrezID))


###################################################
### code chunk number 12: jetset.Rnw:179-183
###################################################
length(na.omit(unique(scores.hgu95av2$EntrezID)))
length(na.omit(unique(scores.hgu133a$EntrezID)))
length(na.omit(unique(scores.hgu133plus2$EntrezID)))
length(na.omit(unique(scores.u133x3p$EntrezID)))


###################################################
### code chunk number 13: sessionInfo
###################################################
sessionInfo()


